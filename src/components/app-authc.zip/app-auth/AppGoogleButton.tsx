import React from 'react';
import { GoogleLogin } from '@react-oauth/google';
import { isNativeAndroid, performNativeGoogleSignIn } from '@/lib/nativeGoogleAuth';

interface AppGoogleButtonProps {
  onGoogleAuth: (idToken: string) => Promise<void>;
  onWebSuccess: (credentialResponse: any) => void;
  loading?: boolean;
  mode?: 'login' | 'signup';
  text?: string;
}

export const AppGoogleButton: React.FC<AppGoogleButtonProps> = ({
  onGoogleAuth,
  onWebSuccess,
  loading = false,
  mode = 'login',
  text = 'Continue with Google',
}) => {
  const handleNativeClick = async () => {
    try {
      const idToken = await performNativeGoogleSignIn();
      if (idToken) {
        await onGoogleAuth(idToken);
      }
    } catch (error: any) {
      console.error('Native Google login error:', error);
      const msg = error?.message || '';
      if (!msg.toLowerCase().includes('cancel') && !msg.toLowerCase().includes('dismiss')) {
        throw error;
      }
    }
  };

  if (isNativeAndroid()) {
    return (
      <button
        type="button"
        onClick={handleNativeClick}
        disabled={loading}
        className="w-full py-3.5 px-4 rounded-xl bg-slate-800/90 border border-slate-700/80 hover:bg-slate-700/80 active:bg-slate-700 text-white font-medium text-sm transition-all duration-200 flex items-center justify-center space-x-3 disabled:opacity-50 disabled:pointer-events-none mb-4 shadow-sm"
      >
        {loading ? (
          <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
          </svg>
        ) : (
          <>
            <svg className="w-5 h-5 bg-white rounded-full p-0.5" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
            </svg>
            <span>{text}</span>
          </>
        )}
      </button>
    );
  }

  return (
    <div className="flex justify-center w-full mb-4">
      <GoogleLogin
        onSuccess={onWebSuccess}
        onError={() => console.log('Google Login error')}
        type="standard"
        size="large"
        theme="filled_blue"
        text={mode === 'login' ? 'signin_with' : 'signup_with'}
        shape="pill"
        width={340}
        logo_alignment="left"
      />
    </div>
  );
};